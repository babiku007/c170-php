<?php
$_db = array(
    'user' => 'studentX',
    'pass' => 'phpP@ssw0rd',
    'host' => 'localhost',
    'dbname' => 'stuX'
);