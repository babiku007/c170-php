<pre>
<?php
$num1 = 100;
$num2 = 200;

echo "sample1</br>";
if ($num1 > $num2) {
    echo "100 > 200</br>";
}

echo "sample2</br>";
if ($num1 > $num2) {
    echo "100 > 200</br>";
} else {
    echo " 200 > 100</br>";
}

echo "sample3</br>";
$num1 = 100;
if ($num1 > 50) {
    echo "1</br>";
} else if ($num1 < 10) {
    echo "2</br>";
}

echo "sample4</br>";
$num1 = 1;
if ($num1 > 50) {
    echo "1</br>";
} else if ($num1 < 10) {
    echo "2</br>";
}
?>
</pre>