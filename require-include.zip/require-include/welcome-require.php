<?php

require "header1.php";
require "body.php";
require "footer.php";